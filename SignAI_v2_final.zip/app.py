"""
SignAI - Sign Language Interpreter Backend
Flask server that serves the frontend and provides TTS + AI Interpretation APIs
"""

import base64
import io
import json
import os
import time

from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from gtts import gTTS

app = Flask(__name__, static_folder='.', static_url_path='')
app.config['SECRET_KEY'] = 'signai-secret-2024'
CORS(app, resources={r"/*": {"origins": "*"}})

# ── Serve Frontend ──────────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# ── Health Check ────────────────────────────────────────────────────
@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'SignAI Backend', 'version': '2.0.0'})

# ── Text to Speech ──────────────────────────────────────────────────
@app.route('/tts', methods=['POST'])
def text_to_speech():
    """Convert text to speech using gTTS, return audio as base64"""
    data = request.get_json()
    text = data.get('text', '').strip()
    if not text:
        return jsonify({'error': 'No text provided'}), 400

    try:
        lang = data.get('lang', 'en')
        tts = gTTS(text=text, lang=lang, slow=False)
        buf = io.BytesIO()
        tts.write_to_fp(buf)
        buf.seek(0)
        audio_b64 = base64.b64encode(buf.read()).decode()
        return jsonify({'audio': 'data:audio/mp3;base64,' + audio_b64, 'text': text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ── AI Interpretation (local fallback) ──────────────────────────────
@app.route('/interpret', methods=['POST'])
def interpret():
    """Provide a local AI interpretation of detected gestures"""
    data = request.get_json()
    text = data.get('text', '')
    mode = data.get('mode', 'alphabet')

    interpretations = {
        'HELLO': 'Greeting: "Hello!" — A standard ASL greeting wave.',
        'I LOVE YOU': '"I love you" — The iconic ILY handshape combining I, L, Y.',
        'YES': 'Affirmation: "Yes" — Fist nodding motion.',
        'NO': 'Negation: "No" — Index and middle fingers snapping on thumb.',
        'THANK YOU': 'Gratitude: "Thank you" — Hand moves from chin forward.',
        'OK': 'Approval: "OK" or "Good"',
        'CALL ME': '"Call me" — Phone shape with thumb and pinky.',
        'GOOD': 'Positive affirmation: "Good" — Index finger pointing up.',
        'WAIT': 'Request to pause: "Wait" — Pinky extended.',
    }

    result = interpretations.get(text.upper(), f'Detected: "{text}"')
    
    # Try to form words from letters
    t = text.upper().strip()
    if t not in interpretations:
        if len(t) <= 5:
            result = f'Detected letters: {"-".join(t)}. This may spell a short word or abbreviation.'
        else:
            result = f'Detected sequence: "{text}". This appears to be a series of ASL signs forming a message.'
    
    return jsonify({'interpretation': result, 'text': text})

# ── Main ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("""
╔══════════════════════════════════════════════╗
║   SignAI — Sign Language Interpreter         ║
║   Server v2.0.0                              ║
║   http://localhost:5000                      ║
╚══════════════════════════════════════════════╝
    """)
    app.run(host='0.0.0.0', port=5000, debug=True)
